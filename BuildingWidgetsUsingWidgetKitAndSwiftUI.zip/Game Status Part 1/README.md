# Emoji Rangers: Part 1

Create a widget using WidgetKit and SwiftUI to show details of a character in a game.

## Overview

- Note: This sample code project is associated with WWDC20 session [10034: Widgets Code-along, part 1: The adventure begins](https://developer.apple.com/wwdc20/10034/).
