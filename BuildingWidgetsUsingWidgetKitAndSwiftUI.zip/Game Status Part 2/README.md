# Emoji Rangers: Part 2

Enhance a widget by supporting multiple sizes, using timelines to stay up to date, and adding user-configurable properties.  

## Overview

- Note: This sample code project is associated with WWDC20 session [10035: Widgets Code-along, part 2: Alternate timelines](https://developer.apple.com/wwdc20/10035/).
