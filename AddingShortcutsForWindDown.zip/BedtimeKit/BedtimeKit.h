/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Umbrella header for the BedtimeKit framework
*/

#import <UIKit/UIKit.h>

//! Project version number for BedtimeKit.
FOUNDATION_EXPORT double BedtimeKitVersionNumber;

//! Project version string for BedtimeKit.
FOUNDATION_EXPORT const unsigned char BedtimeKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BedtimeKit/PublicHeader.h>


